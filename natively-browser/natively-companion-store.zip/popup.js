// src/popup.ts
var $ = (id) => document.getElementById(id);
var dot = $("dot");
var statusText = $("statusText");
var pairCard = $("pairCard");
var captureCard = $("captureCard");
var pairInput = $("pairInput");
var pairBtn = $("pairBtn");
var connectBtn = $("connectBtn");
var captureBtn = $("captureBtn");
var unpairBtn = $("unpairBtn");
var msg = $("msg");
function send(message) {
  return chrome.runtime.sendMessage(message);
}
function setDot(color) {
  dot.className = "dot" + (color === "grey" ? "" : ` ${color}`);
}
function setMsg(text, kind) {
  msg.textContent = text;
  msg.className = "msg" + (kind ? ` ${kind}` : "");
}
function describe(outcome) {
  switch (outcome.kind) {
    case "success":
      return { text: "Sent to Natively.", kind: "ok" };
    case "unauthorized":
      return { text: "Pairing expired (token rotated). Re-pair below.", kind: "warn" };
    case "no-session":
      return { text: "Start a Natively session, then capture again.", kind: "warn" };
    case "refused":
      return { text: "Open Natively and enable Phone Mirror.", kind: "err" };
    case "rate-limited":
      return { text: "Too many requests \u2014 wait a moment and retry.", kind: "warn" };
    case "too-large":
      return { text: "Page too large to send.", kind: "err" };
    case "bad-request":
      return { text: "Desktop rejected the request.", kind: "err" };
    case "http-error":
      return { text: `Unexpected response (${outcome.status}).`, kind: "err" };
    case "error":
      return { text: outcome.message, kind: "err" };
  }
}
function showPaired(paired) {
  pairCard.classList.toggle("hidden", paired);
  captureCard.classList.toggle("hidden", !paired);
}
async function refreshStatus() {
  const outcome = await send({ type: "status" });
  if (outcome.kind === "unpaired" || outcome.kind === "unauthorized") {
    setDot(outcome.kind === "unauthorized" ? "amber" : "grey");
    statusText.textContent = outcome.kind === "unauthorized" ? "Pairing expired \u2014 re-pair" : "Not paired";
    showPaired(false);
    if (outcome.kind === "unauthorized") setMsg("Token rotated on desktop. Re-pair below.", "warn");
    return;
  }
  if (outcome.kind === "success") {
    showPaired(true);
    let wsOpen = false;
    try {
      const r = await send({ type: "ws-status" });
      wsOpen = !!r?.open;
    } catch {
    }
    setDot("green");
    statusText.textContent = wsOpen ? "Connected \u2014 capture ready" : "Connected (connecting capture\u2026)";
    return;
  }
  setDot("red");
  statusText.textContent = outcome.kind === "refused" ? "Desktop offline \u2014 enable Phone Mirror" : "Desktop unreachable";
  showPaired(true);
}
function describePair(outcome) {
  switch (outcome.kind) {
    case "paired":
      return { text: "Connected.", kind: "ok" };
    case "not-armed":
      return { text: 'Click "Connect browser extension" in Natively settings first.', kind: "warn" };
    case "forbidden":
      return { text: "Pairing refused by desktop.", kind: "err" };
    case "refused":
      return { text: "Open Natively and enable Phone Mirror.", kind: "err" };
    case "error":
      return { text: outcome.message, kind: "err" };
  }
}
connectBtn.addEventListener("click", async () => {
  connectBtn.disabled = true;
  setMsg("Connecting\u2026", "");
  const outcome = await send({ type: "autopair" });
  connectBtn.disabled = false;
  if (outcome.kind === "paired") {
    setMsg("Connected.", "ok");
    await refreshStatus();
  } else {
    const d = describePair(outcome);
    setMsg(d.text, d.kind);
  }
});
pairBtn.addEventListener("click", async () => {
  const value = pairInput.value.trim();
  if (!value) return;
  pairBtn.disabled = true;
  setMsg("Pairing\u2026", "");
  const outcome = await send({ type: "pair", value });
  pairBtn.disabled = false;
  if (outcome.kind === "success") {
    pairInput.value = "";
    setMsg("Paired.", "ok");
    await refreshStatus();
  } else {
    const d = describe(outcome);
    setMsg(d.text, d.kind);
  }
});
captureBtn.addEventListener("click", async () => {
  captureBtn.disabled = true;
  setMsg("Capturing\u2026", "");
  const report = await send({ type: "capture" });
  captureBtn.disabled = false;
  const d = describe(report.outcome);
  const suffix = report.outcome.kind === "success" && report.chars ? ` (${report.chars} chars)` : "";
  setMsg(d.text + suffix, d.kind);
  if (report.outcome.kind === "unauthorized") await refreshStatus();
});
unpairBtn.addEventListener("click", async () => {
  await send({ type: "unpair" });
  setMsg("Unpaired.", "");
  await refreshStatus();
});
pairInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") pairBtn.click();
});
void refreshStatus();
/*! For license information please see popup.js.LEGAL.txt */
//# sourceMappingURL=popup.js.map
